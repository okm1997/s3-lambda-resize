import boto3
import os
from PIL import Image
import io
from datetime import datetime, timezone
 
s3 = boto3.client('s3')
sns = boto3.client('sns')
cw = boto3.client('cloudwatch')
 
TARGET_BUCKET = os.environ['TARGET_BUCKET']
SNS_TOPIC_ARN = os.environ['SNS_TOPIC_ARN']
 
def lambda_handler(event, context):

    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        # Check if the uploaded file is a PNG
        if key.endswith('.png'):
            # Get the image from S3
            response = s3.get_object(Bucket=bucket, Key=key)
            image_data = response['Body'].read()
           
            # Resize the image
            image = Image.open(io.BytesIO(image_data))
            image = image.resize((100, 100))
           
            # Save the resized image to a byte stream
            img_byte_arr = io.BytesIO()
            image.save(img_byte_arr, format='PNG')
            img_byte_arr.seek(0)
           
            # Upload the resized image to the target bucket
            resized_key = f'resized-{key}'
            s3.put_object(Bucket=TARGET_BUCKET, Key=resized_key, Body=img_byte_arr)
           
            # Publish a message to the SNS topic
            sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Message=f'Successfully resized image: {resized_key}'
            )

            # Publish a CloudWatch metric for resized images
            cw.put_metric_data(
                Namespace='ImageProcessing',
                MetricData=[{
                    'MetricName': 'ResizedImages',
                    'Dimensions': [
                        {'Name': 'FunctionName', 'Value': context.function_name}
                    ],
                    'Timestamp': datetime.now(timezone.utc),
                    'Value': 1,
                    'Unit': 'Count'
                }]
            )
 
    return {
        'statusCode': 200,
        'body': 'Images processed successfully'
    }
